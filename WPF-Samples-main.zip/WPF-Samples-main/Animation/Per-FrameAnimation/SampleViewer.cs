// // Copyright (c) Microsoft. All rights reserved.
// // Licensed under the MIT license. See LICENSE file in the project root for full license information.

using System.Windows.Controls;

namespace PerFrameAnimation
{
    /// <summary>
    ///     Interaction logic for SampleViewer.xaml
    /// </summary>
    public partial class SampleViewer : Page
    {
        public SampleViewer()
        {
            InitializeComponent();
        }
    }
}